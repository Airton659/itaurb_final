import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:itaurb_transparente/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('End-to-End App Test', () {
    testWidgets('verify app starts and navigates to ColetaTela', (WidgetTester tester) async {
      // Inicia o aplicativo.
      app.main();
      await tester.pumpAndSettle();

      // Verifica se a tela inicial (HomeTela) foi carregada.
      expect(find.text('Pesquisar...'), findsOneWidget);

      // Toca no ícone "Coleta no bairro".
      await tester.tap(find.text('Coleta\nno bairro'));
      await tester.pumpAndSettle();

      // Verifica se a tela de coleta foi aberta.
      expect(find.text('Coleta de Lixo por Bairro'), findsOneWidget);

      // Toca no card de um bairro.
      await tester.tap(find.text('CENTRO'));
      await tester.pumpAndSettle();

      // Verifica se a tela de detalhes do bairro foi aberta e exibe as informações.
      expect(find.text('Coleta Orgânica'), findsOneWidget);
      expect(find.text('Coleta Seletiva (Reciclável)'), findsOneWidget);
      expect(find.text('Coleta de Apoio (Rejeito)'), findsOneWidget);
    });
  });
}